using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Threading;
using SharpDX.DirectInput;
using System.Windows.Forms;

namespace DirectInputNamespace {
    class Program {
        static void Main(string[] args) {

            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();

            DirectInput directinput = new DirectInput();
            Joystick joystick = getJoystick(directinput);
            ObjectProperties objectProperteis = joystick.GetObjectPropertiesById(new DeviceObjectId());


            while(mainWindow.Visible)
            {
                joystick.Acquire();
                JoystickState state = joystick.GetCurrentState();
                int pos_x = state.X;
                int pos_y = state.Y;
                bool[] buttons = state.Buttons;
                mainWindow.positionX_value.Text = pos_x.ToString();
                mainWindow.positionY_value.Text = pos_y.ToString();
                mainWindow.Update();
                if(buttons[0])
                {
                    mainWindow.button1.Text = "pressed";
                }
                else mainWindow.button1.Text = "not pressed";
                Cursor.Position = new System.Drawing.Point(pos_x / 30, pos_y / 30);
                Thread.Sleep(100);
            }
        }

        static Joystick getJoystick(DirectInput directInput)
        {
            IList<DeviceInstance> joysticks = directInput.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AttachedOnly);
            Joystick joystick = new Joystick(directInput, joysticks[0].InstanceGuid);
            IList<DeviceObjectInstance> deviceObjectInstances = joystick.GetObjects();
            foreach(DeviceObjectInstance deviceInstance in joystick.GetObjects())
            {
                joystick = new Joystick(directInput, joysticks[0].InstanceGuid);
            }


            return joystick;
        }
    }
}
