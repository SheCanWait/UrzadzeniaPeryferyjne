﻿namespace DirectInputNamespace
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.positionX = new System.Windows.Forms.Label();
            this.positionY_value = new System.Windows.Forms.Label();
            this.positionX_value = new System.Windows.Forms.Label();
            this.positionY = new System.Windows.Forms.Label();
            this.buttons = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // positionX
            // 
            this.positionX.AutoSize = true;
            this.positionX.Location = new System.Drawing.Point(79, 53);
            this.positionX.Name = "positionX";
            this.positionX.Size = new System.Drawing.Size(75, 20);
            this.positionX.TabIndex = 0;
            this.positionX.Text = "positionX";
            // 
            // positionY_value
            // 
            this.positionY_value.AutoSize = true;
            this.positionY_value.Location = new System.Drawing.Point(625, 53);
            this.positionY_value.Name = "positionY_value";
            this.positionY_value.Size = new System.Drawing.Size(27, 20);
            this.positionY_value.TabIndex = 1;
            this.positionY_value.Text = "66";
            // 
            // positionX_value
            // 
            this.positionX_value.AutoSize = true;
            this.positionX_value.Location = new System.Drawing.Point(239, 53);
            this.positionX_value.Name = "positionX_value";
            this.positionX_value.Size = new System.Drawing.Size(18, 20);
            this.positionX_value.TabIndex = 2;
            this.positionX_value.Text = "5";
            // 
            // positionY
            // 
            this.positionY.AutoSize = true;
            this.positionY.Location = new System.Drawing.Point(506, 53);
            this.positionY.Name = "positionY";
            this.positionY.Size = new System.Drawing.Size(75, 20);
            this.positionY.TabIndex = 3;
            this.positionY.Text = "positionY";
            // 
            // buttons
            // 
            this.buttons.AutoSize = true;
            this.buttons.Location = new System.Drawing.Point(83, 224);
            this.buttons.Name = "buttons";
            this.buttons.Size = new System.Drawing.Size(63, 20);
            this.buttons.TabIndex = 4;
            this.buttons.Text = "buttons";
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Location = new System.Drawing.Point(206, 223);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(93, 20);
            this.button1.TabIndex = 5;
            this.button1.Text = "not pressed";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(223, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "button1";
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttons);
            this.Controls.Add(this.positionY);
            this.Controls.Add(this.positionX_value);
            this.Controls.Add(this.positionY_value);
            this.Controls.Add(this.positionX);
            this.Name = "MainWindow";
            this.Text = "MainWindow";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label positionX;
        public System.Windows.Forms.Label positionY_value;
        public System.Windows.Forms.Label positionX_value;
        public System.Windows.Forms.Label positionY;
        public System.Windows.Forms.Label buttons;
        public System.Windows.Forms.Label button1;
        private System.Windows.Forms.Label label1;
    }
}